Readme.txt
The search results are exported as a tab-delimited text file which imported into spreadsheet, database or other software.
Field 1  contains the BN/Registration Number.
Field 2  contains the Charity Name.
Field 3  contains the Charity Status.
Field 4  contains the Effective Date of Status.
Field 5  contains the Sanction.
Field 6  contains the Designation Code.
Field 7  contains the Category Code.
Field 8  contains the Address.
Field 9  contains the City.
Field 10 contains the Province. 
Field 11 contains the Country.
Field 12 contains the Postal Code.

